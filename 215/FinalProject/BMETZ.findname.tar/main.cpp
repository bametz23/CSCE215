#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

int main(int argc, char *argv[])
{
  char* command_line;
  char buffer[55];
  
//User is found, so return that user
  if(argc = 1)
  {
     cout << (argv[0]);
  }

  //User not found
  if(argc != 0)
  {
    cout << "User "<< argv[0] << " is not registered in 215.\n";
    exit(0);
  }
  
  
  else
  {
    cout << "Sorry, that person is not in CSCE215 this semester";
    exit(0);
  }
  
  
  command_line=argv[1];
  cout << "Sorry that person is not in CSCE215 this semester from the command line." << endl;
  sprintf(command_line, "./findname.sh %s" ,command_line);
  system(command_line);
}
